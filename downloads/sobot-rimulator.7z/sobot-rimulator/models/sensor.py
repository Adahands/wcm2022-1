# AN ABSTRACT SENSOR CLASS


class Sensor:
    def read(self):
        raise NotImplementedError()
