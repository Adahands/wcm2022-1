class GoalReachedException(Exception):
    pass
