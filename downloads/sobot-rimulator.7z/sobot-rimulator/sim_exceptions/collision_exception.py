class CollisionException(Exception):
    pass
