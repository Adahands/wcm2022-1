## SnakeGTK

![](./../img/snakeGTKGame.jpg)

Components:

    sudo apt-get install python-gi-cairo
    sudo apt-get install python-cairo
    sudo apt-get install python-cairocffi

Execute:

    python snakeGTKMain.py
